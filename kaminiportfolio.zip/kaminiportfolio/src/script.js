// script.js

const links = document.querySelectorAll(".nav-links a[data-target]");
const sections = document.querySelectorAll(".content-section");

links.forEach(link => {
  link.addEventListener("click", () => {
    const targetId = link.getAttribute("data-target");
    sections.forEach(sec => {
      sec.classList.remove("active");
    });
    document.getElementById(targetId).classList.add("active");
  });
});
